## README.md

This is the full replication codebase for Lockwood, Sial, and Weinzierl:
Designing, not Checking for Policy Robustness: An Example with Optimal Taxation
To replicate this paper from scratch:
1. Unzip this folder to your computer.
2. Run simulations/code/run_simulations.m in MATLAB. (This may take several hours.)
3. Compile writeup/code/paper.lyx.
