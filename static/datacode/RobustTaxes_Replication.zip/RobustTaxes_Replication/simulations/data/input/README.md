# Data sources

Income data downloaded from http://gabriel-zucman.eu/usdina/
Pilot survey data collected from nine public finance economists.
