# Downloaded from Matlab File Exchange
(Search [here](https://www.mathworks.com/matlabcentral/fileexchange/).)

consolidator.m
interpcon.m
ksr.m

# Custom functions
interpcon.m
