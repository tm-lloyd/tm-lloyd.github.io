function economy = impose_top_rate(economy)
    % imposes the asymptotic top marginal tax rate across high incomes &
    % reoptimzes labor supply accordingly
    
   % Impose asymptotic rate across high incomes
   economy.mtrGrid(economy.incGrid > 300000) = ...
       economy.mtrGrid(economy.incGrid > 300000 & economy.incGrid < 400000);
   for l = 1:length(economy.laborElasts)
       economy.mtr_states(:,l) = interpcon(economy.incGrid, ...
           economy.mtrGrid,economy.inc_states(:,l),'linear','extrap');
   end
   
   % Use fixed point algorithm to reoptimize labor supply
   labor_change = 1;
   inc_step = 0.05; % to ensure convergence
   inc_max = logspace(9,10,length(economy.inc_states))'; % to prevent too large incomes
   j = 1;
   while (labor_change > 1e-4)
       % a. Find new MTR faced by each worker
       for l = 1:length(economy.laborElasts)
           economy.mtr_states(:,l) = interpcon(economy.incGrid, ...
               economy.mtrGrid,economy.inc_states(:,l),'linear','extrap');
       end
       % b. Compute income at new MTR
       inc_states_raw = economy.compute_income(economy.mtr_states);
       % c. Update labor supply
       inc_states_raw = min(max(inc_states_raw,0),inc_max); % limit for convergence
       inc_states_new = inc_step*inc_states_raw + (1 - inc_step)*economy.inc_states;
       % d. Check for convergence
       labor_change = norm(economy.inc_states - inc_states_new,1);
       economy.inc_states = inc_states_new;
       j = j+1;
       if j > 1e6, warning('exceeded iteration limit'); break; end
   end
    
   % Update grant and consumption
   [economy, tax_states] = economy.compute_grant();
   economy = economy.compute_consumption(tax_states);

end
