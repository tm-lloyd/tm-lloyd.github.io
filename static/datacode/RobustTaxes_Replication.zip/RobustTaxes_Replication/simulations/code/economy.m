classdef economy
    % Defines an economy with probability distribution of elasticity states
    
    properties
                
        % Primitives
        revreq;             % revenue requirement
        laborElasts;        % labor elasticity states
        stateProbs;         % state probabilities
        F;                  % type distribution
        wage;               % skill distribution
        k;                  % labor disutility constant
        base_state = 0.4;   % k = 0 in this elasticity state
        incGrid;            % fixed grid of incomes

        % Endogenous choice values for an equilibrium
        mtr_states;         % marginal tax rate states
        mtrGrid;            % marginal tax rate equilibrium
        consump_states      % consumption distribution states
        consumpGrid;        % consumption distribution
        inc_states;         % income distribution states
        grant;              % lump-sum grant
        msww;               % marginal social welfare weights
        alpha;              % unnormalized weights
        lambda;             % marginal value of public funds
        
        % Identifier
        specTitle;
        
    end
    
    
    methods
        
        function obj = economy(data, beliefs, title)
            % Calibrates model primitives to match data, then find equilibrium
            
            % Specify elasticity probability states
            obj.laborElasts = beliefs.laborElasts;
            obj.stateProbs = beliefs.stateProbs;
            obj.specTitle = title;
            
            % Calibrate model parameters
            obj = obj.calibrate(data);
            
            % Find fixed-point tax schedule
            obj = obj.compute_optimal_taxes();
            
            % Confirm optimality with SOC: income non-decreasing in wage
            assert(min(min(diff(obj.inc_states))) >= 0);
            disp("Convergence achieved: " + title);
                        
        end
                
        function obj = calibrate(obj,status_quo)
            % Calibrates primitives of model
            
            % Impose pareto tail at high incomes, retain empirical incomes
            % at low and middle incomes
            zSum = status_quo.pmf .* status_quo.incUS;
            for i = 1:length(status_quo.incUS)
                zBar(i,1) = sum(zSum(i:end))/sum(status_quo.pmf(i:end));
            end
            target = zBar(86)./status_quo.incUS(86); % set benchmark
            function gap = rescale_top_income(x,incUS,pmf,t)
              % For finding the factor x for rescaling the top income  
              inc = [incUS(1:86);zeros(length(pmf(87:end)),1)];
              inc(end) = incUS(end)*x;
              l = length(pmf);
              incSum = zeros(l,1);
              incSum(end) = pmf(end) .* inc(end);
              for p = l-1:-1:87
                  inc(p) = (sum(incSum(p-1:end)) / (t * sum(pmf(p:end)))) / ...
                      (1 - (pmf(p) / (t * sum(pmf(p:end)))));
                  incSum(p) = inc(p) * pmf(p);
              end
              incSum = pmf .* inc;
              gap = ((sum(incSum(86:end))/sum(pmf(86:end)))/inc(86)) - ...
                  ((sum(incSum(87:end))/sum(pmf(87:end)))/inc(87));
            end
            pmfAlt = [status_quo.pmf(1:86);status_quo.pmf(87:95)./6; ...
                status_quo.pmf(87:95)./6;status_quo.pmf(87:95)./6; ...
                status_quo.pmf(87:95)./6;status_quo.pmf(87:95)./6; ...
                status_quo.pmf(87:95)./6;status_quo.pmf(96:104);
                status_quo.pmf(105:5:end).*5]; % more sparse at higher incomes
            FAlt = cumsum(pmfAlt);
            pmfAlt = pmfAlt ./ FAlt(end); % integrates to 1
            fun = @(x) rescale_top_income(x,status_quo.incUS,pmfAlt,target);
            x = fzero(fun,1);
            incAlt = [status_quo.incUS(1:86); ...
                zeros(length(pmfAlt(87:end)),1)]; % the same at low/middle incomes
            last = length(incAlt); % index of the last cell
            zSum = zeros(last,1);
            incAlt(end) = status_quo.incUS(end)*x; 
            zSum(end) = pmfAlt(end) .* incAlt(end);
            for i = last-1:-1:87 % fills in income distribution
                incAlt(i) = (sum(zSum(i-1:end)) / (target * sum(pmfAlt(i:end)))) / ...
                    (1 - (pmfAlt(i) / (target * sum(pmfAlt(i:end)))));
                zSum(i) = incAlt(i) * pmfAlt(i);
            end
            
            status_quo.consumpUS = interpcon(status_quo.incUS, ...
               status_quo.consumpUS,incAlt,'linear','extrap');
            status_quo.incUS = incAlt;
            obj.F = cumsum(pmfAlt);
            N = length(obj.F);
            
            % Rescale to ensure national income equals national consumption
            status_quo.consumpUS = status_quo.consumpUS .* ...
                (1 + (trapz(obj.F, status_quo.incUS - status_quo.consumpUS) / ...
                trapz(obj.F, status_quo.consumpUS)));
            assert(trapz(obj.F,status_quo.incUS - status_quo.consumpUS) < 1e-3);
   
            % Calibrate US tax schedule
            % construct schedule of tax rates: d(z-c)/dz, with kernel
            % smoothing regression
            mtrRaw = diff(status_quo.incUS - status_quo.consumpUS)./ ...
                diff(status_quo.incUS);
            r = ksr(obj.F(2:end),mtrRaw); % chooses optimal bandwidth automatically
            inc_mtrs = interpcon(r.x,r.f,obj.F,'linear','extrap');
            obj.revreq = trapz(obj.F,status_quo.incUS - status_quo.consumpUS);
            obj.grant = status_quo.consumpUS(1);
                        
            % Create income grid with corresponding MTR schedule
            obj.incGrid = [1,7.5,20:12.5:150,175:25:225,275:50:325,400,500,1000,3000,10000,20000]'*1e3;
            obj.mtrGrid = interpcon(status_quo.incUS,inc_mtrs,obj.incGrid,'linear','extrap');
            
            % Initialize values over states
            obj.msww = zeros(N,length(obj.laborElasts));
            obj.consump_states = repmat(status_quo.consumpUS,1, ...
                length(obj.laborElasts));
            obj.inc_states = repmat(status_quo.incUS,1, ...
                length(obj.laborElasts));
            obj.mtr_states = repmat(inc_mtrs,1,length(obj.laborElasts));
            
            % Set primitives
            obj.wage = (obj.inc_states.^(1./obj.laborElasts)./ ...
                (1-obj.mtr_states)).^(obj.laborElasts./(1+obj.laborElasts));
            wage_base = (obj.inc_states.^(1./obj.base_state)./ ...
                (1-obj.mtr_states)).^(obj.base_state./(1+obj.base_state));
            v_base = (1./(1+(1./obj.base_state))) .* ...
                ((obj.inc_states ./ wage_base).^(1+(1./obj.base_state)));
            v = (1./(1+(1./obj.laborElasts))) .* ...
                ((obj.inc_states ./ obj.wage).^(1+(1./obj.laborElasts)));
            obj.k =  v - v_base;
                         
        end
        
        function obj = compute_optimal_taxes(obj)
            % Computes optimal tax schedule and updates equilibrium.

            inc_mtrs_old = obj.mtrGrid;
            policy_change = 1;
            inc_mtrs_change = 1;
            idx = 1;
            limit = max(obj.laborElasts)*length(obj.laborElasts)*1e6;
            
            % 1. Compute marginal social welfare weights (MSWWs)
            obj = obj.compute_mswws();
            
            while (policy_change > 1e-4) || ...
                (inc_mtrs_change > 1e-5) || (idx < 5)
                % require 5 iterations, so everything gets updated
                
                % 2. Update optimal income tax
                [obj.mtrGrid, mtr_prop] = obj.compute_income_tax();
                inc_mtrs_change = norm(obj.mtrGrid - inc_mtrs_old);
                policy_change = max(abs(((mtr_prop(1:end-1)) - ...
                    inc_mtrs_old(1:end-1)) ./ inc_mtrs_old(1:end-1)));
                inc_mtrs_old = obj.mtrGrid;
                
                % 3. Compute optimal labor supply given income tax schedule
                labor_change = 1;
                inc_step = 0.05; % to ensure convergence
                inc_max = logspace(9,10,length(obj.inc_states))';
                j = 1;
                
                while (labor_change > 1e-4)
                    
                    % a. Find new MTR faced by each worker
                    for l = 1:length(obj.laborElasts)
                        obj.mtr_states(:,l) = interpcon(obj.incGrid, ...
                            obj.mtrGrid,obj.inc_states(:,l),'linear','extrap');
                        if obj.mtr_states(end,l) < 0 % impose zero at the bottom result
                            obj.mtr_states(:,l) = interpcon([obj.incGrid;obj.inc_states(end,l)], ...
                                [obj.mtrGrid;0],obj.inc_states(:,l),'linear','extrap');
                        end
                    end
                    
                    % b. Compute income at new MTR
                    mtr_lim = min(obj.mtr_states,.99); % to prevent errors
                    inc_raw = obj.compute_income(mtr_lim);
                    
                    % c. Update labor supply
                    inc_raw = min(max(inc_raw,0),inc_max); % limit for convergence
                    inc_new = inc_step*inc_raw + (1 - inc_step)*obj.inc_states;
                    
                    labor_change = norm(obj.inc_states - inc_new,1);
                    obj.inc_states = inc_new;
                    j = j+1;
                    if j > limit, warning('exceeded iteration limit'); break; end
                    
                end
                
                % 4. Update grant and consumption
                [obj, tax_states] = obj.compute_grant();
                obj = obj.compute_consumption(tax_states);
               
                idx = idx+1;
                if idx > 1e5, warning('exceeded iteration limit'); break; end
                
            end
            
        end
        
        function [mtr_new, mtr_prop] = compute_income_tax(obj)
            % Computes schedule of optimal marginal tax rates for a given equilibrium.
            
            mtr_step = 0.001; % to ensure convergence
            
            [dM, FGrid] = obj.compute_dM();
            denominator = obj.compute_mtr_denom(FGrid);
            mtr_prop = dM ./ denominator;
            
            % smooth and dampen to facilitate convergence
            mtr_lim = min(max(mtr_prop,-.1),1);
            mtr_new = mtr_step*mtr_lim + (1 - mtr_step)*obj.mtrGrid;

        end
        
        function obj = compute_mswws(obj)
            % Computes marginal social welfare weights under a given equilibrium.
            
            obj = obj.compute_mvpf();
            obj.msww = obj.alpha ./ obj.lambda;
            
            % Check that msww average to ~1
            assert(obj.E(trapz(obj.F,obj.msww) - 1) < 1e-3);
            
        end
        
        function obj = compute_mvpf(obj)
            % Computes the marginal value of public funds.

            obj.alpha = 1 ./ (obj.consump_states - ...
                (1./(1+(1./obj.laborElasts))) .* ...
                ((obj.inc_states ./ ...
                obj.wage).^(1+(1./obj.laborElasts))) ...
                + obj.k);
            obj.lambda = obj.E(trapz(obj.F,obj.alpha));
            
        end
        
        function [dM, FGrid] = compute_dM(obj)
            
            % Compute MSWWs in each state
            obj = obj.compute_mswws();
            mswwGrid = zeros(length([0; obj.incGrid]),length(obj.laborElasts));
            FGrid = zeros(length(obj.incGrid),length(obj.laborElasts));
            FExt = zeros(length([0; obj.incGrid]),length(obj.laborElasts));
            for g = 1:length(obj.laborElasts)
                mswwGrid(:,g) = interpcon(obj.inc_states(:,g),obj.msww(:,g), ...
                    [0; obj.incGrid],'linear','extrap');
                FGrid(:,g) = interpcon(obj.inc_states(:,g),obj.F, ...
                    obj.incGrid,'linear','extrap');
                FExt(:,g) = [0; FGrid(:,g)];
            end
            
            % Extend income distribution and MSWWs to zero for purposes of integration
            GExt = zeros(length(FExt),length(obj.laborElasts));
            G = zeros(length(obj.incGrid),length(obj.laborElasts));
            for g = 1:length(obj.laborElasts)
                GExt(:,g) = cumtrapz(FExt(:,g),mswwGrid(:,g));
                G(:,g) = GExt(2:end,g);
                FGrid(:,g) = FGrid(:,g)./FGrid(end,g);
            end
            G = G ./ obj.E(G(end,:)); % normalize so G integrates to 1 across full income distribution in expectation
            
            dM = obj.E(G - FGrid); % mechanical effect
            
        end
        
        function denominator = compute_mtr_denom(obj, FGrid)
            
            % Compute income density in each state
            fGrid = zeros(length(obj.incGrid),length(obj.laborElasts));
            for i = 1:length(obj.laborElasts)
                fGrid(:,i) = economy.derivative(FGrid(:,i),obj.incGrid);
                if fGrid(1,i) < 0 % ensure positive density
                    fRaw = economy.derivative([0;FGrid(:,i)],[0;obj.incGrid]);
                    fGrid(:,i) = fRaw(2:end);
                end
            end
            
            % Compute labor supply response in each state
            dzdt = obj.compute_labor_supply_response(); % compensated earnings response to dt
            dzdtGrid = zeros(length(obj.incGrid),length(obj.laborElasts));
            for h = 1:length(obj.laborElasts)
                dzdtGrid(:,h) = interpcon(obj.inc_states(:,h),dzdt(:,h), ...
                    obj.incGrid,'linear','extrap');
            end
            
            denominator = obj.E(dzdtGrid .* fGrid);
            
        end
        
        function dzdt = compute_labor_supply_response(obj)
            % Computes compensated earnings response to a marginal tax rate perturbation.
            
            SOC_z = obj.compute_SOC_labor_supply();
            dzdt = 1./SOC_z;
   
        end
        
        function SOC_z = compute_SOC_labor_supply(obj)
            % Second-order condition for labor supply choice
            
            % compute 2nd derivative of tax function
            mtr_deriv = zeros(length(obj.F),length(obj.laborElasts));
            for idx = 1:length(obj.laborElasts)
                mtr_deriv(:,idx) = economy.derivative(obj.mtr_states(:,idx), ...
                    obj.inc_states(:,idx));
            end
            
            SOC_z = mtr_deriv + ((1 - obj.mtr_states) ./ ...
                (obj.laborElasts .* obj.inc_states));
            
        end
        
        function income = compute_income(obj,mtr_old)
            % Retrieve income distribution from ability (wage) distribution
            
            income = obj.wage.^(1 + obj.laborElasts) .* ...
                (1 - mtr_old).^obj.laborElasts;
            
        end

        function [obj, inc_tax_states] = compute_grant(obj)
            % Updates grant based on income states and tax schedule
            
            inc_tax_states = zeros(length(obj.F),length(obj.laborElasts));
            for i = 1:length(obj.laborElasts)
                inc_tax_states(:,i) = cumtrapz(obj.inc_states(:,i),obj.mtr_states(:,i));
            end
            revenue_states = trapz(obj.F,inc_tax_states);
            obj.grant = obj.E(revenue_states) - obj.revreq;
            
        end
        
        function obj = compute_consumption(obj, inc_tax_states)
            % Updates grant based on income states, tax schedule, and grant
            
            inc_tax = cumtrapz(obj.incGrid,obj.mtrGrid);
            obj.consumpGrid = obj.grant + obj.incGrid - inc_tax;
            obj.consump_states = obj.grant + obj.inc_states - inc_tax_states;

        end
    
        function exp = E(obj,x)
            % Expectation operator in this context
            
            exp = sum(x.*obj.stateProbs,2);
            
        end
        
    end
    
    methods(Static)
        
        function dydx = derivative(y,x)
            % Computes the derivative of y with respect to x, giving the
            % same number of elements. Uses linear extrapolation.

            dydx_grid = diff(y)./diff(x);
            x_midpoints = (x(1:end-1) + x(2:end))/2;
            dydx = interpcon(x_midpoints,dydx_grid,x,'linear','extrap');

        end
              
    end
    
end
