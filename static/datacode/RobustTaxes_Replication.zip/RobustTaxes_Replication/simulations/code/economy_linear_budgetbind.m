classdef economy_linear_budgetbind < economy_linear
    % Overrides baseline simple linear economy with a binding budget 
    % constraint in each elasticity state
    
    properties
        
        % State-specific marginal value of public funds
        lambda_states;
        
    end
    
    methods
        
        function [mtr_new, mtr_prop] = compute_income_tax(obj)
            % Computes schedule of optimal marginal tax rates for a given equilibrium.
            
            mtr_step = 0.05; % to ensure convergence
            
            % Update MSWWs
            obj = compute_mswws(obj); 
            
            mtr_prop = ((obj.E(obj.lambda_states .* obj.popavg(obj.inc_states)) - ...
                (obj.lambda .* obj.E(obj.popavg(obj.msww .* obj.inc_states)))) / ...
                obj.E(obj.lambda_states .* obj.laborElasts .* ...
                (obj.popavg(obj.inc_states)))) .* (1 - obj.mtrGrid);
            
            % Dampen to facilitate convergence
            mtr_new = mtr_step*mtr_prop + (1 - mtr_step)*obj.mtrGrid;

        end
        
        function obj = compute_mvpf(obj)
            % Computes the marginal value of public funds.

            obj.alpha = 1 ./ (obj.consump_states - ...
                (1./(1+(1./obj.laborElasts))) .* ...
                ((obj.inc_states ./ ...
                obj.wage).^(1+(1./obj.laborElasts))) ...
                + obj.k);
            obj.lambda_states = obj.popavg(obj.alpha);
            obj.lambda = obj.E(obj.lambda_states);
            
        end
        
        function [obj, inc_tax_states] = compute_grant(obj)
            % Updates grant based on income states and tax
            
            inc_tax_states = zeros(2,length(obj.laborElasts));
            for i = 1:length(obj.laborElasts)
                inc_tax_states(:,i) = obj.inc_states(:,i) .* obj.mtrGrid;
            end
            revenue_states = obj.popavg(inc_tax_states);
            obj.grant = revenue_states - obj.revreq;
            
        end    
        
    end
    
end
    