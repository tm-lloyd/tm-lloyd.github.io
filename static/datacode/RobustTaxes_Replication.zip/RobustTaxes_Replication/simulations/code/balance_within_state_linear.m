function economy = balance_within_state_linear(certain_economy, ...
    uncertain_economy)
    % Ensures the budget constraint binds in each state when the best
    % estimate policy is implemented, computing a lump-sum grant in each
    % elasticity state
    
    % Update income in each state under best estimate tax policy
    income_states = uncertain_economy.compute_income(certain_economy.mtrGrid);
    
    % Update grant based on income states and tax schedule
    inc_tax_states = zeros(2,length(uncertain_economy.laborElasts));
    for i = 1:length(uncertain_economy.laborElasts)
        inc_tax_states(:,i) = income_states(:,i) .* certain_economy.mtrGrid;
    end
    revenue_states = certain_economy.popavg(inc_tax_states);
    grant = revenue_states - certain_economy.revreq;
    
    % Redefine economy with within state budget balance
    economy = certain_economy;
    economy.grant = grant;
    economy.inc_states = income_states;
    economy.consump_states = grant + income_states - inc_tax_states;
     
end