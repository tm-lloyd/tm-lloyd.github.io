function run_simulations()
% Simulate robust and best estimate optimal nonlinear and linear income 
% taxes using PSZ income distribution.

clear all;
addpath(genpath('./functions/'));
addpath(genpath('../lib/matlab/'));

global DATADIR OUTPUT VERBOSE;
DATADIR = '../data';
OUTPUT = '../output';
VERBOSE = false; % report verbose logging to console?

diaryfile = [OUTPUT '/logfile_new.txt'];
if (exist(diaryfile,'file')), delete(diaryfile); end
diary(diaryfile);
numbersfile = [OUTPUT '/numbersfortext.tex'];
if (exist(numbersfile,'file')), delete(numbersfile); end 


%% Compute structural results

% Load PSZ income and consumption distribution data
D = load_data();

% Specify elasticity beliefs over states
% certain baseline
B_certain.laborElasts = .4; % best estimate
B_certain.stateProbs = 1;

% uncertain baseline
B_uncertain.laborElasts = [0.1 1.1];
B_uncertain.stateProbs = [.7 .3];

% uncertain skewed
B_uncertSkew.laborElasts = [0.1 0.2 2.6];
B_uncertSkew.stateProbs = [0.4 0.5 0.1];

% pilot survey of academic economists
B_survey = load_survey_beliefs();

% certain baseline for comparison with survey data
B_certain_survey.laborElasts = B_survey.laborElasts * ...
    B_survey.stateProbs'; % best estimate
B_certain_survey.stateProbs = 1;

% Store results of different specifications in cells
ResultsLinear = { economy_linear(D, B_certain, 'Certain linear') ...
    economy_linear(D, B_uncertain, 'Uncertain linear, baseline') ...
    economy_linear_budgetbind(D, B_uncertain, 'Uncertain linear, baseline, bind') };

ResultsBaseline = { economy(D, B_certain, 'Certain') ...
    economy(D, B_uncertain, 'Uncertain, baseline') ...
    economy_budgetbind(D, B_uncertain, 'Uncertain, baseline, bind') };

ResultsSkewed = { ResultsBaseline{1} ...
    economy(D, B_uncertSkew, 'Uncertain, skewed') ...
    economy_budgetbind(D, B_uncertSkew, 'Uncertain, skewed, bind') };
ResultsSkewed{1}.specTitle = 'Certain, skewed';

ResultsSurvey = { economy(D, B_certain_survey, 'Certain, survey') ...
    economy(D, B_survey, 'Uncertain, survey') ...
    economy_budgetbind(D, B_survey, 'Uncertain, survey, bind') };

% Store all results in one cell
Results = { ResultsLinear ResultsBaseline ResultsSkewed ResultsSurvey };

% Add certainty specifications with within-state budget constraints
for i = 1:4
   if i == 1
       Results{i}{4} =  balance_within_state_linear(Results{i}{1},Results{i}{3});
   else
       Results{i}{4} =  balance_within_state(Results{i}{1},Results{i}{3});
   end
   Results{i}{4}.specTitle = Results{i}{1}.specTitle + ", bind";
end

% Impose asymptotic top rate across high incomes
for i = 2:4
    for j = 1:4
        Results{i}{j} = impose_top_rate(Results{i}{j});
    end
end


%% Export results from simple linear tax illustration

% Tax rates
for i = 1:4
    name = lower(erasePunctuation(replace(Results{1}{i}.specTitle,' ','')));
    latex_command(strcat(name,'tax'), Results{1}{i}.mtrGrid*100, '%2.1f');
end
latex_command('statusquotax', Results{1}{1}.status_quo_t*100, '%2.1f');

% Grants
n = {'one','two','three','four','five','six'};
for i = 1:4
    name = lower(erasePunctuation(replace(Results{1}{i}.specTitle,' ','')));
    if length(Results{1}{i}.grant) == 1
        latex_command(name, round(Results{1}{i}.grant), 'grant');
    else
        grants = Results{1}{i}.grant;
        for j = 1:length(grants)
            latex_command(strcat(name,n(j)), round(grants(j)), 'grant');
        end
    end
end
latex_command('statusquogrant', round(Results{1}{1}.status_quo_grant), 'grant');


%% Plot marginal tax rates across income distribution

LineStyles = {'-','--',':',':'};
Colors = {'k','r','b','k'};
incScale = 1e-3;
ubound = 3.5*10^5;
horizAxisTitle = 'Income ($1000s)';
specName = {'baseline','skew','survey'};

for i = 2:4 % beliefs
    for j = 1:3 % specs
        % plot marginal tax rate schedule, dropping the lowest cell
        plot(Results{i}{j}.incGrid(2:end)*incScale,Results{i}{j}.mtrGrid(2:end), ...
            'Color',Colors{j},'LineStyle',LineStyles{j},'LineWidth',2);
        hold on;
    end

    xlim([0 ubound*incScale]);
    ylim([0.2 0.8]);
    legend({'Best estimate','Robust, fully pre-specified', ...
        'Robust, within-state balance'},'location','southeast','FontSize',10);
    set(gca,'fontsize',14);
    xlabel(horizAxisTitle);
    ylabel('Marginal tax rate');
    
    figpath = "/Figures/tax_rates_" + specName{i-1} + "_mtr.pdf";
    fname = OUTPUT + figpath;
    fig = gcf;
    fig.PaperPositionMode = 'auto';
    fig_pos = fig.PaperPosition;
    fig.PaperSize = [fig_pos(3) fig_pos(4)];
    print(fig,fname,'-dpdf');
    
    figpath = "/Figures/tax_rates_" + specName{i-1} + "_mtr.eps";
    fname = OUTPUT + figpath;
    saveas(fig,fname,'epsc');
    close;
    
end


%% Plot average tax rates across income distribution

for i = 2:4 % beliefs
    for j = [1 4 2 3] % specs
        
        if size(Results{i}{j}.consumpGrid,2) > 1 % specs with within-state budget constraints
            atr_exp = zeros(length(Results{i}{j}.incGrid),1);
            for k = 1:size(Results{i}{j}.consumpGrid,2)
                % compute average tax rate in each state
                atr_state = (Results{i}{j}.incGrid - Results{i}{j}.consumpGrid(:,k)) ./ ...
                    Results{i}{j}.incGrid; 
                % compute expectation of average tax rates
                atr_exp = atr_exp + Results{i}{j}.stateProbs(k)*atr_state;
            end
            plot(Results{i}{1}.incGrid*incScale,atr_exp, ...
                'Color',Colors{j},'LineStyle',LineStyles{j},'LineWidth',2);
            
        else % specs with budget constraint that binds in expectation
            % compute average tax rate
            atr = (Results{i}{j}.incGrid - Results{i}{j}.consumpGrid) ./ ...
                Results{i}{j}.incGrid;
            plot(Results{i}{1}.incGrid*incScale,atr, ...
                'Color',Colors{j},'LineStyle',LineStyles{j},'LineWidth',2);
        end
        hold on;
    end

    xlim([0 ubound*incScale]);
    ylim([-.4 .6]);
    legend({'Best estimate, fully pre-specified', ...
        'Best estimate, within-state balance, expectation', ...   
        'Robust, fully pre-specified', ...
        'Robust, within-state balance, expectation'}, ...
        'location','southeast','FontSize',10,'AutoUpdate','off');
    plot(xlim(),[0,0],'Color','k');
    set(gca,'fontsize',14);
    xlabel(horizAxisTitle);
    ylabel('Average tax rate');

    figpath = "/Figures/tax_rates_" + specName{i-1} + "_atr.pdf";
    fname = OUTPUT + figpath;
    fig = gcf;
    fig.PaperPositionMode = 'auto';
    fig_pos = fig.PaperPosition;
    fig.PaperSize = [fig_pos(3) fig_pos(4)];
    print(fig,fname,'-dpdf');
    
    figpath = "/Figures/tax_rates_" + specName{i-1} + "_atr.eps";
    fname = OUTPUT + figpath;
    saveas(fig,fname,'epsc');
    close;
    
end


%% Plot change in average tax rate across specifications

MarkerStyles = {'o','x','s','d','^','*'};
for i = 2:4 % beliefs
    
    % compute average tax rates under certainty (best esimate), dropping 
    % the lowest cell
    atr_certain{1} = (Results{i}{1}.incGrid(2:end) - ...
        Results{i}{1}.consumpGrid(2:end)) ./ Results{i}{1}.incGrid(2:end);
    atr_certain{2} = (Results{i}{4}.incGrid(2:end) - ...
        Results{i}{4}.consumpGrid(2:end,:)) ./ Results{i}{4}.incGrid(2:end);
    
    for j = 2:3 % uncertainty specs (robust)
        
        if size(Results{i}{j}.consumpGrid,2) > 1 % with within-state budget constraints
            atr_diff_exp = zeros(length(Results{i}{j}.incGrid(2:end)),1);
            for k = 1:size(Results{i}{j}.consumpGrid,2)
                % compute difference in average tax rates in each state
                atr_diff_state = ((Results{i}{j}.incGrid(2:end) - ...
                    Results{i}{j}.consumpGrid(2:end,k)) ./ ...
                    Results{i}{j}.incGrid(2:end)) - atr_certain{j-1}(:,k);
                plot(Results{i}{1}.incGrid(2:end)*incScale,atr_diff_state, ...
                    'Color','b','LineStyle',LineStyles{j},'LineWidth',.75, ...
                    'Marker',MarkerStyles{k},'MarkerSize',4);
                % compute expectation of difference in average tax rates
                atr_diff_exp = atr_diff_exp + Results{i}{j}.stateProbs(k)*atr_diff_state;
            end
        plot(Results{i}{1}.incGrid(2:end)*incScale,atr_diff_exp, ...
            'Color','b','LineStyle',':','LineWidth',2,'Marker','none');
        
        else % with budget constraint that binds in expectation
            % compute difference in average tax rates
            atr_diff = ((Results{i}{j}.incGrid(2:end) - ...
                Results{i}{j}.consumpGrid(2:end)) ./ ...
                Results{i}{j}.incGrid(2:end)) - atr_certain{j-1};
            plot(Results{i}{1}.incGrid(2:end)*incScale,atr_diff, ...
                'Color',Colors{j},'LineStyle',LineStyles{j},'LineWidth',2);
        end
        hold on;
    end

    xlim([0 ubound*incScale]);
    if i == 2
        ylim([-.16 .16]);
        yticks(-0.16:.04:.16);
        legend({'Fully pre-specified', ...
            'Within-state balance, \sigma = 0.1', ...
            'Within-state balance, \sigma = 1.1', ...
            'Within-state balance, expectation', ...
            },'location','southeast','FontSize',10,'AutoUpdate','off');
    elseif i == 3
        ylim([-.16 .16]);
        yticks(-0.16:.04:.16);
        legend({'Fully pre-specified', ...
            'Within-state balance, \sigma = 0.1', ...
            'Within-state balance, \sigma = 0.2', ...
            'Within-state balance, \sigma = 2.6', ...
            'Within-state balance, expectation', ...
            },'location','southeast','FontSize',10,'AutoUpdate','off');
    elseif i == 4
        ylim([-.08 .08]);
        yticks(-0.08:.02:.08);
        legend({'Fully pre-specified', ...
            'Within-state balance, \sigma = 0.1', ...
            'Within-state balance, \sigma = 0.2', ...
            'Within-state balance, \sigma = 0.4', ...
            'Within-state balance, \sigma = 0.75', ...
            'Within-state balance, \sigma = 1.5', ...
            'Within-state balance, \sigma = 2.5', ...
            'Within-state balance, expectation', ...
            },'location','southeast','FontSize',10,'AutoUpdate','off');
    end
    plot(xlim(),[0,0],'Color','k');
    set(gca,'fontsize',14);
    xlabel(horizAxisTitle);
    ylabel('Average tax rate change');

    figpath = "/Figures/tax_rates_" + specName{i-1} + "_atr_diff.pdf";
    fname = OUTPUT + figpath;
    fig = gcf;
    fig.PaperPositionMode = 'auto';
    fig_pos = fig.PaperPosition;
    fig.PaperSize = [fig_pos(3) fig_pos(4)];
    print(fig,fname,'-dpdf');
    
    figpath = "/Figures/tax_rates_" + specName{i-1} + "_atr_diff.eps";
    fname = OUTPUT + figpath;
    saveas(fig,fname,'epsc');
    close;

end


%% Export grant amounts

for i = 2:4
    for j = 1:length(Results{i})
        name = lower(erasePunctuation(replace(Results{i}{j}.specTitle,' ','')));
        if length(Results{i}{j}.grant) == 1
            latex_command(name, round(Results{i}{j}.grant), 'grant');
        else
            for k = 1:length(Results{i}{j}.grant)
                latex_command(strcat(name,n(k)), ...
                    round(Results{i}{j}.grant(k)), 'grant');
            end
        end
    end
end


%% Export and plot probability states and elasticities from survey

latex_command('svyexpelast', B_certain_survey.laborElasts, "%1.2f")
for i = 1:length(B_survey.laborElasts)
    prob = B_survey.stateProbs(i)*100;
    latex_command(strcat('svyelast',n(i)), B_survey.laborElasts(i), "%1.2f")
    latex_command(strcat('svyprob',n(i)), prob, "%2.1f")
end

% plot survey results
plot_survey_data(B_survey);


%% Compute and export welfare effect results

specName = {'baseline','skewed','survey'};
for i = 2:4
    
    % for specs where the budget constraint binds in expectation
    we = compute_welfare_effect(Results{i}{2}, Results{i}{1});
    % expected money-metric welfare gain from robustness
    latex_command(strcat('we',specName{i-1}), we.delta_welfare_exp, "%4.0f");
    % expected welfare gain from robustness relative to consumption
    latex_command(strcat('weconsump',specName{i-1}), ...
        we.delta_welfare_consump_exp*100, "%2.1f");
    if i == 4
        survey_effects = [we.delta_welfare_exp we.delta_welfare_states];
    end
    
    % for specs with within-state budget constraints
    we = compute_welfare_effect(Results{i}{3}, Results{i}{4});
    % expected money-metric welfare gain from robustness
    latex_command(strcat('we',specName{i-1},'bind'), we.delta_welfare_exp, "%4.0f");
    % expected welfare gain from robustness relative to consumption
    latex_command(strcat('weconsump',specName{i-1},'bind'), ...
        we.delta_welfare_consump_exp*100, "%2.1f");
    if i == 4
        survey_bind_effects = [we.delta_welfare_exp we.delta_welfare_states];
    end
    
end


%% Plot welfare effects for the survey specification in each state

y = [survey_effects; survey_bind_effects]';
b = bar(0:6,y,1);
b(1).FaceColor = 'r';
b(2).FaceColor = 'b';
row1 = {'Expectation','\sigma = 0.1','\sigma = 0.2','\sigma = 0.4', ...
    '\sigma = 0.75','\sigma = 1.5','\sigma = 2.5'};
row2 = {'',"\pi = " + compose('%1.2f', B_survey.stateProbs(1)), ...
    "\pi = " + compose('%1.2f', B_survey.stateProbs(2)), ...
    "\pi = " + compose('%1.2f', B_survey.stateProbs(3)), ...
    "\pi = " + compose('%1.2f', B_survey.stateProbs(4)), ...
    "\pi = " + compose('%1.2f', B_survey.stateProbs(5)), ...
    "\pi = " + compose('%1.2f', B_survey.stateProbs(6))};
labelArray = [row1; row2];
tickLabels = strtrim(sprintf('%s\\newline%s\n', labelArray{:}));
ylabel('Welfare effect ($ billions)');
ylim([-200 300]);
legend({'Gains from robustness, fully pre-specified', ...
    'Gains from robustness, within-state balance'},'location','southwest');
set(gcf,'color','w');
set(gcf,'Position',[100 100 600 450])
set(gca,'fontsize',10);
set(gca,'XTickLabel',tickLabels);

fname = [OUTPUT '/Figures/welfare_effects.pdf'];
fig = gcf;
fig.PaperPositionMode = 'auto';
fig_pos = fig.PaperPosition;
fig.PaperSize = [fig_pos(3) fig_pos(4)];
print(fig,fname,'-dpdf');

fname = [OUTPUT '/Figures/welfare_effects.eps'];
saveas(fig,fname,'epsc');

% add version with box around expectation of effects
annotation('rectangle',[0.135 .4 .1 .375],'Color','g','LineWidth',2);
fname = [OUTPUT '/Figures/welfare_effects_boxed.pdf'];
fig = gcf;
fig.PaperPositionMode = 'auto';
fig_pos = fig.PaperPosition;
fig.PaperSize = [fig_pos(3) fig_pos(4)];
print(fig,fname,'-dpdf');
close;


%% Export changes in rates across incomes

% Increases in rates across high incomes
% Survey, budget constraint binds in expectation, marginal tax rates
rate_incr = round(mean(Results{4}{2}.mtrGrid(15:18) - ...
    Results{4}{1}.mtrGrid(15:18)),3)*100;
latex_command('svyratesincr', rate_incr, "%2.0f");

% Survey, within-state budget constraints, marginal tax rates
rate_incr = round(mean(Results{4}{3}.mtrGrid(15:18) - ...
    Results{4}{4}.mtrGrid(15:18)),3)*100;
latex_command('svybindratesincr', rate_incr, "%2.0f");

% Survey, budget constraint binds in expectation, average tax rates
atr_uncertain = (Results{4}{2}.incGrid - Results{4}{2}.consumpGrid) ./ ...
    Results{4}{2}.incGrid;
atr_certain = (Results{4}{1}.incGrid - Results{4}{1}.consumpGrid) ./ ...
    Results{4}{1}.incGrid;
rate_incr = round(mean(atr_uncertain(15:18) - atr_certain(15:18)),3)*100;
latex_command('svyatrincr', rate_incr, "%2.0f");

% Survey, within-state budget constraints, average tax rates
atr_certain = zeros(length(Results{4}{4}.incGrid),1);
for i = 1:size(Results{4}{4}.consumpGrid,2)
    atr_certain = atr_certain + B_survey.stateProbs(i) .* ...
      ((Results{4}{4}.incGrid - Results{4}{4}.consumpGrid(:,i)) ./ ...
      Results{4}{4}.incGrid);
end
atr_uncertain = zeros(length(Results{4}{3}.incGrid),1);
for i = 1:size(Results{4}{3}.consumpGrid,2)
    atr_uncertain = atr_uncertain + B_survey.stateProbs(i) .* ...
      ((Results{4}{3}.incGrid - Results{4}{3}.consumpGrid(:,i)) ./ ...
      Results{4}{3}.incGrid);
end
rate_incr = round(mean(atr_uncertain(15:18) - atr_certain(15:18)),3)*100;
latex_command('svybindatrincr', rate_incr, "%2.0f");

% Decreases in rates across low incomes
% Survey, budget constraint binds in expectation, average tax rates
atr_uncertain = (Results{4}{2}.incGrid - Results{4}{2}.consumpGrid) ./ ...
    Results{4}{2}.incGrid;
atr_certain = (Results{4}{1}.incGrid - Results{4}{1}.consumpGrid) ./ ...
    Results{4}{1}.incGrid;
rate_decr = abs(round(mean(atr_uncertain(2:3) - atr_certain(2:3)),3)*100);
latex_command('svyatrdecrhi', rate_decr, "%2.0f");
rate_decr = abs(round(mean(atr_uncertain(6) - atr_certain(6)),3)*100);
latex_command('svyatrdecrlow', rate_decr, "%2.0f");


%% Display and export results

save([OUTPUT '/results_workspace.mat'],'Results');
disp('Finished.')
diary off;


%% Helper functions for loading and exporting data

function survey_beliefs = load_survey_beliefs()
    % load beliefs from survey

    [elasts,~,~] = xlsread([DATADIR '/input/PilotETISurveyData.xlsx'], ...
        'Cleaned data', 'D13:I13');
    [probs,~,~] = xlsread([DATADIR '/input/PilotETISurveyData.xlsx'], ...
        'Cleaned data', 'D15:I15');

    survey_beliefs.laborElasts = elasts;
    survey_beliefs.stateProbs = probs;

end

function status_quo = load_data()
    % load PSZ income and consumption distribution data

    [~, ~, raw] = xlsread([DATADIR '/input/PSZ2017MainData.xlsx'],'DataFS40');
    raw = raw(3:133,[2,15,23]);
    raw(cellfun(@(x) ~isempty(x) && isnumeric(x) && isnan(x),raw)) = {''};
    R = cellfun(@(x) ~isnumeric(x) && ~islogical(x),raw); % Find non-numeric cells
    raw(R) = {NaN}; % Replace non-numeric cells
    data = reshape([raw{:}],size(raw));

    cdf = data(2:end,1);
    pmf = diff(cdf);
    z = data(3:end ,2); % pre-tax income
    c = data(3:end,3); % post-tax income

    % drop bottom tail with incomes below $500 (bottom 4% of population;
    % also drop rows with pmf == 0, which comes from data error in original
    % spreadsheet, which repeated rows for pctiles 99, 99.9, and 99.99
    toKeep = (z > 500 & pmf > 0);
    pmf = pmf(toKeep);
    pmf = pmf/sum(pmf); % ensure sums exactly to 1
    z = z(toKeep);
    c = c(toKeep);

    status_quo.pmf = pmf;
    status_quo.incUS = z;
    status_quo.consumpUS = c;

end

function plot_survey_data(beliefs)
    % plot the average probability assigned to each elasticity state
     
    bar(1:6,beliefs.stateProbs);
    ylabel('Mean probability');
    xlabel('Elasticity of taxable income');
    xticklabels({'< 0.1','0.1-0.3','0.3-0.5','0.5-1.0','1.0-2.0','> 2.0'});
    ylim([0 .4]);
    yticks([0 .1 .2 .3 .4]);
    set(gcf,'color','w');
    set(gca,'fontsize',10);
    fpath = [OUTPUT '/Figures/survey_results.pdf'];
    svyfig = gcf;
    svyfig.PaperPositionMode = 'auto';
    svyfig_pos = svyfig.PaperPosition;
    svyfig.PaperSize = [svyfig_pos(3) svyfig_pos(4)];
    print(svyfig,fpath,'-dpdf');
    
    fpath = [OUTPUT '/Figures/survey_results.eps'];
    saveas(svyfig,fpath,'epsc');
    close;
        
end

function latex_command(name, value, format)
    % export a value as a latex command

    if strcmp(format, 'grant')
        df = java.text.DecimalFormat; % comma for thousands
        value = char(df.format(round(value)));
        value = strrep(value,',','{,}');
    else
        value = compose(format, value);
    end
    
    nc = "\newcommand{\";
    if ismac, nc = "\\\newcommand{\\"; end
    input = nc + name + "}{" + value + "}";

    file = [OUTPUT '/numbersfortext.tex'];
    command = "echo " + input + " >> " + file;
    system(command);

end

end
