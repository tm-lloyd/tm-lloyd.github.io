classdef economy_linear < economy
    % Defines a simple economy with two types, a probability distribution
    % elasticity states, and a linear tax
    
    properties
        
        % Status quo values
        status_quo_t;           % linear tax rate
        status_quo_grant;       % lump-sum grant
        
    end
    
    methods
        
        function obj = calibrate(obj,status_quo)
            % Calibrates primitives of model
            
            % Define two types of individuals at the status quo
            obj.F = [0;0.5;1];
            income = [status_quo.incUS(24);status_quo.incUS(72)];
            consump = [status_quo.consumpUS(24);status_quo.consumpUS(72)];
    
            % Initialize linear tax
            t = 1 - ((consump(2) - consump(1))/(income(2) - income(1)));
            obj.grant = consump(1) - (income(1)*(1 - t));
            obj.revreq = obj.popavg(income - consump);
            consump = consump + obj.revreq; % balance the budget
            obj.revreq = obj.popavg(income - consump);
            
            % Store status quo tax
            obj.status_quo_t = t;
            obj.status_quo_grant = obj.grant;

            % Initialize values over states
            obj.msww = zeros(2,length(obj.laborElasts));
            obj.consump_states = repmat(consump,1,length(obj.laborElasts));
            obj.inc_states = repmat(income,1,length(obj.laborElasts));
            obj.mtrGrid = t;
                        
            % Set primitives
            obj.wage = (obj.inc_states.^(1./obj.laborElasts)./ ...
                (1-obj.mtrGrid)).^(obj.laborElasts./(1+obj.laborElasts));
            wage_base = (obj.inc_states.^(1./obj.base_state)./ ...
                (1-obj.mtrGrid)).^(obj.base_state./(1+obj.base_state));
            v_base = (1./(1+(1./obj.base_state))) .* ...
                ((obj.inc_states ./ wage_base).^(1+(1./obj.base_state)));
            v = (1./(1+(1./obj.laborElasts))) .* ...
                ((obj.inc_states ./ obj.wage).^(1+(1./obj.laborElasts)));
            obj.k =  v - v_base;
            
        end
        
        function obj = compute_optimal_taxes(obj)
            % Computes optimal tax and updates equilibrium
            
            t_old = obj.mtrGrid;
            policy_change = 1;
            idx = 1;
            
            while (policy_change > 1e-4) || ...
                (t_change > 1e-5) || (idx < 5)
                % require 5 iterations, so everything gets updated
                
                % 1. Update optimal income tax
                [obj.mtrGrid, mtr_prop] = obj.compute_income_tax();
                t_change = norm(obj.mtrGrid - t_old);
                policy_change = (mtr_prop - t_old) ./ t_old;
                t_old = obj.mtrGrid;
                
                % 2. Update labor supply given income tax
                obj.inc_states = obj.compute_income(obj.mtrGrid);
                
                % 3. Update grant and consumption
                [obj, tax_states] = obj.compute_grant();
                obj = obj.compute_consumption(tax_states);
               
                idx = idx+1;
                if idx > 1e5, warning('exceeded iteration limit'); break; end
            
            end
            
        end
        
        function [mtr_new, mtr_prop] = compute_income_tax(obj)
            % Computes schedule of optimal marginal tax rates for a given equilibrium.
            
            mtr_step = 0.05; % to ensure convergence
            
            % Update MSWWs
            obj = compute_mswws(obj); 

            mtr_prop = ((obj.E(obj.popavg(obj.inc_states)) - ...
                obj.E(obj.popavg(obj.msww .* obj.inc_states))) / ...
                obj.E(obj.popavg(obj.laborElasts .* ...
                obj.inc_states))) .* (1 - obj.mtrGrid);
            
            % Dampen to facilitate convergence
            mtr_new = mtr_step*mtr_prop + (1 - mtr_step)*obj.mtrGrid;
            
        end
        
        function obj = compute_mswws(obj)
            % Computes marginal social welfare weights under a given equilibrium.
            
            obj = obj.compute_mvpf();
            obj.msww = obj.alpha ./ obj.lambda;
            
            % Check that msww average to ~1
            assert(obj.E(obj.popavg(obj.msww) - 1) < 1e-3);
            
        end
        
        function obj = compute_mvpf(obj)
            % Computes the marginal value of public funds.

            obj.alpha = 1 ./ (obj.consump_states - ...
                (1./(1+(1./obj.laborElasts))) .* ...
                ((obj.inc_states ./ ...
                obj.wage).^(1+(1./obj.laborElasts))) ...
                + obj.k);
            obj.lambda = obj.E(obj.popavg(obj.alpha));
            
        end
        
        function [obj, inc_tax_states] = compute_grant(obj)
            % Updates grant based on income states and tax
            
            inc_tax_states = zeros(2,length(obj.laborElasts));
            for i = 1:length(obj.laborElasts)
                inc_tax_states(:,i) = obj.inc_states(:,i) .* obj.mtrGrid;
            end
            revenue_states = obj.popavg(inc_tax_states);
            obj.grant = obj.E(revenue_states) - obj.revreq;
            
        end
        
        function obj = compute_consumption(obj, inc_tax_states)
            % Updates grant based on income states, tax, and grant
            
            obj.consump_states = obj.grant + obj.inc_states - inc_tax_states;

        end
        
        function avg = popavg(obj,x)
            % Compute population average within each state
            
            avg = sum(x.*diff(obj.F),1);
            
        end
        
    end
    
end

        