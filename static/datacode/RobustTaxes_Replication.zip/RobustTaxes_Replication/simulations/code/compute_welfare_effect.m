function we = compute_welfare_effect(uncertain_economy, certain_economy)
    % computes the expected money-metric welfare effect from tax rates 
    % accounting for uncertainty relative to rates which do not account for
    % uncertainty
    
    we.elasts = uncertain_economy.laborElasts;
    
    % compute welfare under tax rates accounting for uncertainty
    welfare_states_uncertain = log(uncertain_economy.consump_states - ...
        ((1./(1+(1./uncertain_economy.laborElasts))) .* ...
        ((uncertain_economy.inc_states ./ uncertain_economy.wage).^ ...
        ((1./uncertain_economy.laborElasts) + 1))) + uncertain_economy.k);
    
    % compute income & consumption under tax rates not accounting for uncertainty
    % 1. Initialize incomes
    income_states = uncertain_economy.inc_states;
    mtr_states = uncertain_economy.mtr_states; % for size
    % 2. Use fixed point algorithm to arrive at optimal labor supply
    labor_change = 1;
    inc_step = 0.05; % to ensure convergence
    inc_max = logspace(9,10,length(income_states))'; % to prevent too large incomes
    j = 1;
    while (labor_change > 1e-4)
        % a. Find new MTR faced by each worker
        for l = 1:length(uncertain_economy.laborElasts)
            mtr_states(:,l) = interpcon(certain_economy.incGrid, ...
                certain_economy.mtrGrid,income_states(:,l),'linear','extrap');
            if mtr_states(end,l) < 0 % impose zero at the bottom result
                mtr_states(:,l) = interpcon([certain_economy.incGrid; ...
                    income_states(end,l)],[certain_economy.mtrGrid;0], ...
                    income_states(:,l),'linear','extrap');
            end
        end
        % b. Compute income at new MTR
        mtr_states = min(mtr_states,.99); % to prevent errors
        income_states_raw = uncertain_economy.compute_income(mtr_states);
        % c. Update labor supply
        income_states_raw = min(max(income_states_raw,0),inc_max); % limit for convergence
        income_states_new = inc_step*income_states_raw + (1 - inc_step)*income_states;
        % d. Check for convergence
        labor_change = norm(income_states - income_states_new,1);
        income_states = income_states_new;
        j = j+1;
        if j > 1e6, warning('exceeded iteration limit'); break; end
    end
    % 3. compute tax in each state
    inc_tax_states = zeros(length(income_states(:,1)), ...
        length(uncertain_economy.laborElasts));
    for i = 1:length(uncertain_economy.laborElasts)
        inc_tax_states(:,i) = cumtrapz(income_states(:,i),mtr_states(:,i));
    end
    % 4. compute consumption in each state
    consump_states = certain_economy.grant + income_states - inc_tax_states;
    
    % compute welfare under tax rates not accounting for uncertainty
    welfare_states_certain = log(consump_states - ...
        ((1./(1+(1./uncertain_economy.laborElasts))) .* ...
        ((income_states ./ uncertain_economy.wage).^ ...
        ((1./uncertain_economy.laborElasts) + 1))) + uncertain_economy.k);
    
    % compute marginal value of public funds in each state
    certain_economy.alpha = 1 ./ (consump_states - ...
        (1./(1+(1./uncertain_economy.laborElasts))) .* ...
        ((income_states ./ uncertain_economy.wage).^ ...
        (1+(1./uncertain_economy.laborElasts))) + uncertain_economy.k);
    certain_economy.lambda = trapz(certain_economy.F,certain_economy.alpha);
    
    % compute welfare effect & convert from utils to dollars
    pmf = [uncertain_economy.F(1);diff(uncertain_economy.F)];
    welfare_states_diff = welfare_states_uncertain - welfare_states_certain;
    welfare_states_diff = welfare_states_diff ./ certain_economy.lambda;
    delta_welfare_states = sum(pmf .* welfare_states_diff);
    delta_welfare_exp = uncertain_economy.E(delta_welfare_states);
    
    % multiply by population size for aggregate effect
    USPop = .318; % in billions
    we.delta_welfare_states = delta_welfare_states .* USPop;
    we.delta_welfare_exp = delta_welfare_exp .* USPop;
    
    % divide by aggregate consumption under certainty for scale of effect
    agg_consump = trapz(certain_economy.F, consump_states) .* USPop;
    we.delta_welfare_consump_states = we.delta_welfare_states ./ agg_consump;
    we.delta_welfare_consump_exp = uncertain_economy.E(we.delta_welfare_consump_states);

end
