function economy = balance_within_state(certain_economy, uncertain_economy)
    % Ensures the budget constraint binds in each state when the best
    % estimate policy is implemented, computing a lump-sum grant in each
    % elasticity state

    % Update income in each state under best estimate tax policy
    % 1. Initialize incomes
    income_states = repmat(certain_economy.inc_states,1, ...
                length(uncertain_economy.laborElasts));
    mtr_states = repmat(certain_economy.mtr_states,1, ...
                length(uncertain_economy.laborElasts));
    % 2. Use fixed point algorithm to arrive at optimal labor supply
    labor_change = 1;
    inc_step = 0.05; % to ensure convergence
    inc_max = logspace(9,10,length(income_states))'; % to prevent too large incomes
    j = 1;
    while (labor_change > 1e-4)
        % a. Find new MTR faced by each worker
        for l = 1:length(uncertain_economy.laborElasts)
            mtr_states(:,l) = interpcon(certain_economy.incGrid,certain_economy.mtrGrid, ...
                income_states(:,l),'linear','extrap');
            if mtr_states(end,l) < 0 % impose zero at the bottom result
                mtr_states(:,l) = interpcon([certain_economy.incGrid;income_states(end,l)], ...
                    [certain_economy.mtrGrid;0],income_states(:,l),'linear','extrap');
            end
        end
        % b. Compute income at new MTR
        mtr_states = min(mtr_states,.99); % to prevent errors
        income_states_raw = uncertain_economy.compute_income(mtr_states);
        % c. Update labor supply
        income_states_raw = min(max(income_states_raw,0),inc_max); % limit for convergence
        income_states_new = inc_step*income_states_raw + (1 - inc_step)*income_states;
        % d. Check for convergence
        labor_change = norm(income_states - income_states_new,1);
        income_states = income_states_new;
        j = j+1;
        if j > 1e6, warning('exceeded iteration limit'); break; end
    end
    
    % Update grant based on income states and tax schedule
    inc_tax_states = zeros(length(certain_economy.F), ...
        length(uncertain_economy.laborElasts));
    for i = 1:length(uncertain_economy.laborElasts)
        inc_tax_states(:,i) = cumtrapz(income_states(:,i),mtr_states(:,i));
    end
    revenue_states = trapz(certain_economy.F,inc_tax_states);
    grant = revenue_states - certain_economy.revreq;
    inc_tax = cumtrapz(certain_economy.incGrid,certain_economy.mtrGrid);
    
    % Redefine economy with within state budget balance
    economy = uncertain_economy;
    economy.grant = grant;
    economy.inc_states = income_states;
    economy.mtr_states = mtr_states;
    economy.mtrGrid = certain_economy.mtrGrid;
    economy.consump_states = grant + income_states - inc_tax_states;
    economy.consumpGrid = grant + certain_economy.incGrid - inc_tax;
    economy.msww = certain_economy.msww;
    economy.alpha = certain_economy.alpha;
    economy.lambda = certain_economy.lambda;
 
end
    