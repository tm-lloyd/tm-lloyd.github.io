classdef economy_budgetbind < economy
    % Overrides baseline economy with a binding budget constraint in each
    % elasticity state
    
    properties
        
        % State-specific marginal value of public funds
        lambda_states;
        
    end
    
    methods
        
        function obj = compute_mvpf(obj)
            % Computes the marginal value of public funds in each state

            obj.alpha = 1 ./ (obj.consump_states - ...
                (1./(1+(1./obj.laborElasts))) .* ...
                ((obj.inc_states ./ ...
                obj.wage).^(1+(1./obj.laborElasts))) ...
                + obj.k);
            obj.lambda_states = trapz(obj.F,obj.alpha);
            obj.lambda = obj.E(obj.lambda_states);
            
        end
        
        function [dM, FGrid] = compute_dM(obj)
            
            % Compute MSWWs in each state
            obj = obj.compute_mswws();
            mswwGrid = zeros(length([0; obj.incGrid]),length(obj.laborElasts));
            FGrid = zeros(length(obj.incGrid),length(obj.laborElasts));
            FExt = zeros(length([0; obj.incGrid]),length(obj.laborElasts));
            for g = 1:length(obj.laborElasts)
                mswwGrid(:,g) = interpcon(obj.inc_states(:,g),obj.msww(:,g), ...
                    [0; obj.incGrid],'linear','extrap');
                FGrid(:,g) = interpcon(obj.inc_states(:,g),obj.F, ...
                    obj.incGrid,'linear','extrap');
                FExt(:,g) = [0; FGrid(:,g)];
            end
            
            % Extend income distribution and MSWWs to zero for purposes of
            % integration and multiply by the MVPF
            GExt = zeros(length(FExt),length(obj.laborElasts));
            G = zeros(length(obj.incGrid),length(obj.laborElasts));
            for g = 1:length(obj.laborElasts)
                GExt(:,g) = cumtrapz(FExt(:,g),mswwGrid(:,g) .* obj.lambda);
                G(:,g) = GExt(2:end,g);
                G(:,g) = G(:,g)./(G(end,g)./obj.lambda_states(g)); % normalize so G integrates to MVPF across full income distribution
                FGrid(:,g) = FGrid(:,g)./FGrid(end,g); % integrates to 1 across full income distribution
            end

            dM = obj.E(G - (obj.lambda_states .* FGrid)); % mechanical effect
            
        end
        
        function denominator = compute_mtr_denom(obj, FGrid)
            
            % Compute income density in each state
            fGrid = zeros(length(obj.incGrid),length(obj.laborElasts));
            for i = 1:length(obj.laborElasts)
                fGrid(:,i) = economy.derivative(FGrid(:,i),obj.incGrid);
                if fGrid(1,i) < 0 % ensure positive density
                    fRaw = economy.derivative([0;FGrid(:,i)],[0;obj.incGrid]);
                    fGrid(:,i) = fRaw(2:end);
                end
            end
            
            % Compute labor supply response in each state
            dzdt = obj.compute_labor_supply_response(); % compensated earnings response to dt
            dzdtGrid = zeros(length(obj.incGrid),length(obj.laborElasts));
            for h = 1:length(obj.laborElasts)
                dzdtGrid(:,h) = interpcon(obj.inc_states(:,h),dzdt(:,h), ...
                    obj.incGrid,'linear','extrap');
            end
            
            obj = obj.compute_mvpf(); % obtain state-specific MVPF
            denominator = obj.E(obj.lambda_states .* dzdtGrid .* fGrid);
            
        end
        
        function [obj, inc_tax_states] = compute_grant(obj)
            % Updates grant based on income states and tax schedule
            
            inc_tax_states = zeros(length(obj.F),length(obj.laborElasts));
            for i = 1:length(obj.laborElasts)
                inc_tax_states(:,i) = cumtrapz(obj.inc_states(:,i),obj.mtr_states(:,i));
            end
            revenue_states = trapz(obj.F,inc_tax_states);
            obj.grant = revenue_states - obj.revreq;
            
        end
        
    end

end
